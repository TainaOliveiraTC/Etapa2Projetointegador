
package Model.bean;

public class Receitas {
  private int idreceitas;
  private double receitadia;
  private double receitageral;
  private double valordespesa;

    public int getIdreceitas() {
        return idreceitas;
    }

    public void setIdreceitas(int idreceitas) {
        this.idreceitas = idreceitas;
    }

    public double getReceitadia() {
        return receitadia;
    }

    public void setReceitadia(double receitadia) {
        this.receitadia = receitadia;
    }

    public double getReceitageral() {
        return receitageral;
    }

    public void setReceitageral(double receitageral) {
        this.receitageral = receitageral;
    }

    public double getValordespesa() {
        return valordespesa;
    }

    public void setValordespesa(double valordespesa) {
        this.valordespesa = valordespesa;
    }

    
}
