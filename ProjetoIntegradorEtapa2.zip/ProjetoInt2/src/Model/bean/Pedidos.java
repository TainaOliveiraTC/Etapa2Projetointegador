
package Model.bean;

public class Pedidos {
  private int idpedidos;
  private String nomeproduto;
  private String nomecliente;
  private int numeromesa;
  private int quantidadeproduto;
  private String status;

}
