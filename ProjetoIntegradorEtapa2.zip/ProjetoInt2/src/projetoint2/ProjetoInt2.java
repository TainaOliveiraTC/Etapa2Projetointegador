
package projetoint2;
import java.awt.GridBagLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
public class ProjetoInt2 {

    public static void main(String[] args) {
          JFrame miJFrame = new JFrame("Pagina Login");
          miJFrame.setSize(500,300); 
          JPanel miJPanel = new JPanel();
          miJPanel.setSize(300, 300);
          miJPanel.setLayout(new GridBagLayout());
           JLabel miJLabel = new JLabel();
        
        
        
    }
    
}
